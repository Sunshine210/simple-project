package cn.tarena.weather.entity;

public class Pm25 {
	private String quality;
	public String getQuality() {
		return quality;
	}
	public void setQuality(String quality) {
		this.quality = quality;
	}
}
