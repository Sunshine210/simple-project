package cn.tarena.weather.entity;

public class Info {
	private String []day;
	private String []night;
	public String [] getDay() {
		return day;
	}//ctrl+s   alt+/
	public void setDay(String [] day) {
		this.day = day;
	}
	public String [] getNight() {
		return night;
	}
	public void setNight(String [] night) {
		this.night = night;
	}

}
