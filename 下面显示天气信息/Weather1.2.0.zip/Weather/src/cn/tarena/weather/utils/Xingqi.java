package cn.tarena.weather.utils;

public class Xingqi {
	public static String nx(int str) {
		switch (str) {
		case 1:
			return "һ";
		case 2:
			return "��";
		case 3:
			return "��";
		case 4:
			return "��";
		case 5:
			return "��";
		case 6:
			return "��";
		case 7:
			return "��";
		}
		return "��";
	}
}