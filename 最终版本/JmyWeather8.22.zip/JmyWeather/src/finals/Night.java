package finals;

public class Night {
}
