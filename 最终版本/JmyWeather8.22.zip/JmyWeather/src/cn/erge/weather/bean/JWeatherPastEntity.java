package cn.erge.weather.bean;

public class JWeatherPastEntity extends JBaseEntity {

}
