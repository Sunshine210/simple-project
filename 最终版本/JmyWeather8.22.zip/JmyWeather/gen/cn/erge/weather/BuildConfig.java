/** Automatically generated file. DO NOT MODIFY */
package cn.erge.weather;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}