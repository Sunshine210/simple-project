/** Automatically generated file. DO NOT MODIFY */
package com.example.usermanager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}