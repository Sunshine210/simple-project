package com.example.usermanager.view;

import com.example.usermanager.R;
import com.example.usermanager.R.layout;

import android.app.Activity;
import android.os.Bundle;

public class RegisterActivity extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register_activity);
	}
}
